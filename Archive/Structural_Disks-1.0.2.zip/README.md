# StructuralDisks

For KSP 1.2


To install extract contents of the GameData folder to yourKSPfolder/GameData/
