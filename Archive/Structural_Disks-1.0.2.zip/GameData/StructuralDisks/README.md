# Structural Disks

Structural Disks adds new structural parts based off the structural panels already in the
game. Instead, these panels (or disks) are circular and come in 0.625m, 1.25m, 2.5m and
3.75m diameters. Each disk also has multiple textures to choose from, thanks to Interstellar
Fuel Switch.

If you find any bugs or suggestions please report them at http://forum.kerbalspaceprogram.com/index.php?/topic/150867-12-structural-disks-like-panels-but-circular/

##Thanks to:
-InsaneDruid for help early on with getting textures to work

-Phineas Freak for help with FStextureswitch configs

-snjo for creating Firespitter and all of it's modules

-FreeThinker for improving upon what snjo did with Interstellar Fuel Switch


##Dependancies:
This mod depends on the Interstellar Fuel Switch core (or the Firespitter core) by FreeThinker 
which has it's own license. Visit https://goo.gl/WdB1Vt to find out more.

Structural Disks also requires Module Manager by Sarbian. Visit https://goo.gl/wncyRq to learn 
more.

##KSP Mini-AVC
Structural Disks includes version checking using MiniAVC. If you opt-in, it will use the internet to check whether there is a new version available. Data is only read from the internet and no personal information is sent. For a more comprehensive version checking experience, please download the KSP-AVC Plugin.


-Benji13
